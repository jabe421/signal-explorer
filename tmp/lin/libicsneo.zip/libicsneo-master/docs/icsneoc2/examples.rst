=================
icsneoc2 Examples
=================

Simple
======

:download:`Download example <../../examples/c2/simple/src/main.c>`

.. literalinclude:: ../../examples/c2/simple/src/main.c
   :language: c

Supported Devices
=================

:download:`Download example <../../examples/c2/supported_devices/src/main.c>`

.. literalinclude:: ../../examples/c2/supported_devices/src/main.c
   :language: c

Disk Format
===========

:download:`Download example <../../examples/c2/diskformat/src/main.c>`

.. literalinclude:: ../../examples/c2/diskformat/src/main.c
   :language: c

Read Messages
=============

:download:`Download example <../../examples/c2/read_messages/src/main.c>`

.. literalinclude:: ../../examples/c2/read_messages/src/main.c
   :language: c

Device Info
===========

:download:`Download example <../../examples/c2/device_info/src/main.c>`

.. literalinclude:: ../../examples/c2/device_info/src/main.c
   :language: c

LIN
===

:download:`Download example <../../examples/c2/lin/src/main.c>`

.. literalinclude:: ../../examples/c2/lin/src/main.c
   :language: c

LIN Transmit
============

:download:`Download example <../../examples/c2/lin_transmit/src/main.c>`

.. literalinclude:: ../../examples/c2/lin_transmit/src/main.c
   :language: c

Ethernet Transmit
=================

:download:`Download example <../../examples/c2/ethernet_transmit/src/main.c>`

.. literalinclude:: ../../examples/c2/ethernet_transmit/src/main.c
   :language: c

Ethernet Receive
================

:download:`Download example <../../examples/c2/ethernet_receive/src/main.c>`

.. literalinclude:: ../../examples/c2/ethernet_receive/src/main.c
   :language: c

Ethernet Status
===============

:download:`Download example <../../examples/c2/ethernet_status/src/main.c>`

.. literalinclude:: ../../examples/c2/ethernet_status/src/main.c
   :language: c

T1S Loopback
============

:download:`Download example <../../examples/c2/t1s_loopback/src/main.c>`

.. literalinclude:: ../../examples/c2/t1s_loopback/src/main.c
   :language: c

TC10
====

:download:`Download example <../../examples/c2/tc10/src/main.c>`

.. literalinclude:: ../../examples/c2/tc10/src/main.c
   :language: c

gPTP
====

:download:`Download example <../../examples/c2/gptp/src/main.c>`

.. literalinclude:: ../../examples/c2/gptp/src/main.c
   :language: c

PerfTest
========

:download:`Download example <../../examples/c2/perf_test/src/main.c>`

.. literalinclude:: ../../examples/c2/perf_test/src/main.c
   :language: c

Termination Groups
==================

:download:`Download example <../../examples/c2/termination/src/main.c>`

.. literalinclude:: ../../examples/c2/termination/src/main.c
   :language: c

