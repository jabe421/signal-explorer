@setlocal
@echo off

mkdir build >nul 2>&1

cmake -GNinja -Bbuild -DCMAKE_BUILD_TYPE=Release -DCMAKE_COMPILE_WARNING_AS_ERROR=ON -DLIBICSNEO_BUILD_UNIT_TESTS=ON -DLIBICSNEO_ENABLE_TCP=ON -DLIBICSNEO_ENABLE_BOOTLOADER=ON || exit /b 1

cmake --build build || exit /b 1
