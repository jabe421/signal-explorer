===============
Python Examples
===============

Transmit CAN frames on DW CAN 01
=================================

:download:`Download example <../../examples/python/can/can_transmit_basic.py>`

.. literalinclude:: ../../examples/python/can/can_transmit_basic.py
   :language: python
     
Receive CAN frames on DW CAN 01
================================

:download:`Download example <../../examples/python/can/can_receive_basic.py>`

.. literalinclude:: ../../examples/python/can/can_receive_basic.py
   :language: python

Complete CAN Example
====================

:download:`Download example <../../examples/python/can/can_complete_example.py>`

.. literalinclude:: ../../examples/python/can/can_complete_example.py
   :language: python


LiveData Subscription and Monitoring
=====================================

:download:`Download example <../../examples/python/livedata/livedata_example.py>`

.. literalinclude:: ../../examples/python/livedata/livedata_example.py
   :language: python


Transmit Ethernet frames on Ethernet 01
========================================

:download:`Download example <../../examples/python/ethernet/ethernet_transmit_basic.py>`

.. literalinclude:: ../../examples/python/ethernet/ethernet_transmit_basic.py
   :language: python

Monitor Ethernet Status
=======================

:download:`Download example <../../examples/python/ethernet/ethernet_monitor_status.py>`

.. literalinclude:: ../../examples/python/ethernet/ethernet_monitor_status.py
   :language: python

TC10 Power Management
=====================

:download:`Download example <../../examples/python/tc10/tc10.py>`

.. literalinclude:: ../../examples/python/tc10/tc10.py
   :language: python

DoIP Ethernet Activation
========================

:download:`Download example <../../examples/python/doip/doip_activation_control.py>`

.. literalinclude:: ../../examples/python/doip/doip_activation_control.py
   :language: python

Complete Ethernet Example
=========================

:download:`Download example <../../examples/python/ethernet/ethernet_complete_example.py>`

.. literalinclude:: ../../examples/python/ethernet/ethernet_complete_example.py
   :language: python

Device Firmware/Chip Versions
=============================

:download:`Download example <../../examples/python/device/chip_versions.py>`

.. literalinclude:: ../../examples/python/device/chip_versions.py
   :language: python

SPI Example for 10BASE-T1S
=============================

:download:`Download example <../../examples/python/spi/spi_example.py>`

.. literalinclude:: ../../examples/python/spi/spi_example.py
   :language: python

10BASE-T1S Settings Configuration
=================================

:download:`Download example <../../examples/python/t1s/t1s_settings.py>`

.. literalinclude:: ../../examples/python/t1s/t1s_settings.py
   :language: python

Analog Output Control
=====================

:download:`Download example <../../examples/python/analog_out/analog_out_basic.py>`

.. literalinclude:: ../../examples/python/analog_out/analog_out_basic.py
   :language: python

ISO-TP CAN1 Loopback
====================

Two devices, CAN1 wired together. ``--raw`` checks the cable, ``--sf`` sends one
firmware single frame, ``--both`` sends a segmented payload with firmware flow control.

:download:`Download example <../../examples/python/iso15765/iso15765_loopback.py>`

.. literalinclude:: ../../examples/python/iso15765/iso15765_loopback.py
   :language: python

Firmware Update
===============

Updates the first device found from a ``fw.bin`` or firmware bundle, see
:doc:`firmware_update`.

:download:`Download example <../../examples/python/bootloader/update.py>`

.. literalinclude:: ../../examples/python/bootloader/update.py
   :language: python
