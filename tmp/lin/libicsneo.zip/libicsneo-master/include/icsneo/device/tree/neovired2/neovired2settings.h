#ifndef __NEOVIRED2SETTINGS_H_
#define __NEOVIRED2SETTINGS_H_

#include <stdint.h>
#include "icsneo/device/idevicesettings.h"

#ifdef __cplusplus

namespace icsneo {

#endif

#ifdef _MSC_VER
#pragma warning(push)
#pragma warning(disable : 4201) // nameless struct/union
#endif

#pragma pack(push, 2)
typedef struct {
	uint16_t perf_en;
	uint16_t network_enabled_on_boot;
	uint16_t misc_io_on_report_events;
	uint16_t pwr_man_enable;
	int16_t iso15765_separation_time_offset;
	uint16_t slaveVnetA;
	uint32_t reserved;
	uint64_t termination_enables;
	union {
		uint64_t word;
		struct
		{
			uint16_t network_enables;
			uint16_t network_enables_2;
			uint16_t network_enables_3;
		};
	} network_enables;
	uint32_t pwr_man_timeout;
	CAN_SETTINGS can1;
	CANFD_SETTINGS canfd1;
	CAN_SETTINGS can2;
	CANFD_SETTINGS canfd2;
	CAN_SETTINGS can3;
	CANFD_SETTINGS canfd3;
	CAN_SETTINGS can4;
	CANFD_SETTINGS canfd4;
	CAN_SETTINGS can5;
	CANFD_SETTINGS canfd5;
	CAN_SETTINGS can6;
	CANFD_SETTINGS canfd6;
	CAN_SETTINGS can7;
	CANFD_SETTINGS canfd7;
	CAN_SETTINGS can8;
	CANFD_SETTINGS canfd8;
	LIN_SETTINGS lin1;
	LIN_SETTINGS lin2;
	ISO9141_KEYWORD2000_SETTINGS iso9141_kwp_settings_1;
	uint16_t iso_parity_1;
	uint16_t iso_msg_termination_1;
	ISO9141_KEYWORD2000_SETTINGS iso9141_kwp_settings_2;
	uint16_t iso_parity_2;
	uint16_t iso_msg_termination_2;
	ETHERNET_SETTINGS ethernet;
	TIMESYNC_ICSHARDWARE_SETTINGS timeSync;
	STextAPISettings text_api;
	struct {
		uint32_t disableUsbCheckOnBoot : 1;
		uint32_t enableLatencyTest : 1;
		uint32_t busMessagesToAndroid : 1;
		uint32_t enablePcEthernetComm : 1;
		uint32_t enableDefaultLogger : 1;
		uint32_t enableDefaultUpload : 1;
		uint32_t reserved : 26;
	} flags;
	DISK_SETTINGS disk;
	uint16_t misc_io_report_period;
	uint16_t ain_threshold;
	uint16_t misc_io_analog_enable;
	uint16_t digitalIoThresholdTicks;
	uint16_t digitalIoThresholdEnable;
	uint16_t misc_io_initial_ddr;
	uint16_t misc_io_initial_latch;
	ETHERNET_SETTINGS2 ethernet2_1;
	ETHERNET_SETTINGS ethernet_2;
	ETHERNET_SETTINGS2 ethernet2_2;
	Fire3LinuxSettings os_settings;
	RAD_GPTP_SETTINGS gPTP;
	uint16_t iso_tester_pullup_enable;
	CMP_GLOBAL_DATA cmp_global_data;
	CMP_NETWORK_DATA cmp_stream_data[CMP_STREAMS_RED2];
	uint32_t networkTimeSync;
} neovired2_settings_t;

typedef struct {
	uint8_t backupPowerGood;
	uint8_t backupPowerEnabled;
	uint8_t usbHostPowerEnabled;
	uint8_t ethernetActivationLineEnabled;
	EthernetNetworkStatus ethernetStatus;
} neovired2_status_t;
#pragma pack(pop)

#ifdef _MSC_VER
#pragma warning(pop)
#endif

#ifdef __cplusplus

static_assert(sizeof(neovired2_settings_t) == 918, "NeoVIRED2 settings size mismatch");

#include <iostream>

class NeoVIRED2Settings : public IDeviceSettings {
public:
	NeoVIRED2Settings(Device* device) : IDeviceSettings(device, sizeof(neovired2_settings_t)) {}
	const Fire3LinuxSettings* getLinuxSettings() const override {
		auto cfg = getStructurePointer<neovired2_settings_t>();
		return cfg ? &cfg->os_settings : nullptr;
	}
	std::optional<Fire3LinuxSettings*> getMutableLinuxSettings() override {
		auto cfg = getMutableStructurePointer<neovired2_settings_t>();
		if(cfg == nullptr)
			return std::nullopt;
		return &cfg->os_settings;
	}
	const CAN_SETTINGS* getCANSettingsFor(Network net) const override {
		auto cfg = getStructurePointer<neovired2_settings_t>();
		if(cfg == nullptr)
			return nullptr;
		switch(net.getNetID()) {
			case Network::NetID::DWCAN_01:
				return &(cfg->can1);
			case Network::NetID::DWCAN_02:
				return &(cfg->can2);
			case Network::NetID::DWCAN_03:
				return &(cfg->can3);
			case Network::NetID::DWCAN_04:
				return &(cfg->can4);
			case Network::NetID::DWCAN_05:
				return &(cfg->can5);
			case Network::NetID::DWCAN_06:
				return &(cfg->can6);
			case Network::NetID::DWCAN_07:
				return &(cfg->can7);
			case Network::NetID::DWCAN_08:
				return &(cfg->can8);
			default:
				return nullptr;
		}
	}
	
	const CANFD_SETTINGS* getCANFDSettingsFor(Network net) const override {
		auto cfg = getStructurePointer<neovired2_settings_t>();
		if(cfg == nullptr)
			return nullptr;
		switch(net.getNetID()) {
			case Network::NetID::DWCAN_01:
				return &(cfg->canfd1);
			case Network::NetID::DWCAN_02:
				return &(cfg->canfd2);
			case Network::NetID::DWCAN_03:
				return &(cfg->canfd3);
			case Network::NetID::DWCAN_04:
				return &(cfg->canfd4);
			case Network::NetID::DWCAN_05:
				return &(cfg->canfd5);
			case Network::NetID::DWCAN_06:
				return &(cfg->canfd6);
			case Network::NetID::DWCAN_07:
				return &(cfg->canfd7);
			case Network::NetID::DWCAN_08:
				return &(cfg->canfd8);
			default:
				return nullptr;
		}
	}

	virtual std::vector<TerminationGroup> getTerminationGroups() const override {
		// RED2 has a single physical termination bank: DW CAN 01-08. Termination
		// within the bank is actually independent (any number may be enabled at
		// once).
		return {
			{
				Network(Network::NetID::DWCAN_01),
				Network(Network::NetID::DWCAN_02),
				Network(Network::NetID::DWCAN_03),
				Network(Network::NetID::DWCAN_04),
				Network(Network::NetID::DWCAN_05),
				Network(Network::NetID::DWCAN_06),
				Network(Network::NetID::DWCAN_07),
				Network(Network::NetID::DWCAN_08)
			}
		};
	}

	const LIN_SETTINGS* getLINSettingsFor(Network net) const override {
		auto cfg = getStructurePointer<neovired2_settings_t>();
		if(cfg == nullptr)
			return nullptr;
		switch(net.getNetID()) {
			case Network::NetID::LIN_01:
				return &(cfg->lin1);
			case Network::NetID::LIN_02:
				return &(cfg->lin2);
			default:
				return nullptr;
		}
	}

	const ETHERNET_SETTINGS2* getEthernetSettingsFor(Network net) const override {
		auto cfg = getStructurePointer<neovired2_settings_t>();
		if(cfg == nullptr)
			return nullptr;
		switch(net.getNetID()) {
			case Network::NetID::ETHERNET_01:
				return &(cfg->ethernet2_1);
			case Network::NetID::ETHERNET_02:
				return &(cfg->ethernet2_2);
			default:
				return nullptr;
		}
	}

	std::vector<EthPhyLinkMode> getSupportedPhyLinkModesFor(Network net) const override {
		switch(net.getNetID()) {
			case Network::NetID::ETHERNET_01:
			case Network::NetID::ETHERNET_02:
				return {
					ETH_LINK_MODE_AUTO_NEGOTIATION,
					ETH_LINK_MODE_10MBPS_FULLDUPLEX,
					ETH_LINK_MODE_10MBPS_HALFDUPLEX,
					ETH_LINK_MODE_100MBPS_FULLDUPLEX,
					ETH_LINK_MODE_100MBPS_HALFDUPLEX,
					ETH_LINK_MODE_1GBPS_FULLDUPLEX
				};
			default:
				return {};
		}
	}

	bool setPhyLinkModeFor(Network net, EthPhyLinkMode mode) override {
		auto supported = getSupportedPhyLinkModesFor(net);
		if(std::find(supported.begin(), supported.end(), mode) == supported.end()) {
			report(APIEvent::Type::ParameterOutOfRange, APIEvent::Severity::Error);
			return false;
		}

		ETHERNET_SETTINGS2* eth = getMutableEthernetSettingsFor(net);
		if(eth == nullptr)
			return false;

		switch(mode) {
			case ETH_LINK_MODE_AUTO_NEGOTIATION:
				eth->flags |= ETHERNET_SETTINGS2_FLAG_AUTO_NEG;
				eth->link_speed = 2;
				eth->flags |= ETHERNET_SETTINGS2_FLAG_FULL_DUPLEX;
				break;
			case ETH_LINK_MODE_10MBPS_FULLDUPLEX:
				eth->link_speed = 0;
				eth->flags &= ~ETHERNET_SETTINGS2_FLAG_AUTO_NEG;
				eth->flags |= ETHERNET_SETTINGS2_FLAG_FULL_DUPLEX;
				break;
			case ETH_LINK_MODE_10MBPS_HALFDUPLEX:
				eth->link_speed = 0;
				eth->flags &= ~ETHERNET_SETTINGS2_FLAG_AUTO_NEG;
				eth->flags &= ~ETHERNET_SETTINGS2_FLAG_FULL_DUPLEX;
				break;
			case ETH_LINK_MODE_100MBPS_FULLDUPLEX:
				eth->link_speed = 1;
				eth->flags &= ~ETHERNET_SETTINGS2_FLAG_AUTO_NEG;
				eth->flags |= ETHERNET_SETTINGS2_FLAG_FULL_DUPLEX;
				break;
			case ETH_LINK_MODE_100MBPS_HALFDUPLEX:
				eth->link_speed = 1;
				eth->flags &= ~ETHERNET_SETTINGS2_FLAG_AUTO_NEG;
				eth->flags &= ~ETHERNET_SETTINGS2_FLAG_FULL_DUPLEX;
				break;
			case ETH_LINK_MODE_1GBPS_FULLDUPLEX:
				eth->link_speed = 2;
				eth->flags &= ~ETHERNET_SETTINGS2_FLAG_AUTO_NEG;
				eth->flags |= ETHERNET_SETTINGS2_FLAG_FULL_DUPLEX;
				break;
			default:
				report(APIEvent::Type::ParameterOutOfRange, APIEvent::Severity::Error);
				return false;
		}
		return true;
	}

	std::optional<EthPhyLinkMode> getPhyLinkModeFor(Network net) const override {
		const ETHERNET_SETTINGS2* eth = getEthernetSettingsFor(net);
		if(eth == nullptr) {
			report(APIEvent::Type::ParameterOutOfRange, APIEvent::Severity::Error);
			return std::nullopt;
		}

		if(eth->flags & ETHERNET_SETTINGS2_FLAG_AUTO_NEG)
			return ETH_LINK_MODE_AUTO_NEGOTIATION;

		const bool fullDuplex = (eth->flags & ETHERNET_SETTINGS2_FLAG_FULL_DUPLEX) != 0;
		switch(eth->link_speed) {
			case 0: return fullDuplex ? ETH_LINK_MODE_10MBPS_FULLDUPLEX : ETH_LINK_MODE_10MBPS_HALFDUPLEX;
			case 1: return fullDuplex ? ETH_LINK_MODE_100MBPS_FULLDUPLEX : ETH_LINK_MODE_100MBPS_HALFDUPLEX;
			case 2: return fullDuplex ? ETH_LINK_MODE_1GBPS_FULLDUPLEX : ETH_LINK_MODE_1GBPS_HALFDUPLEX;
			default:
				report(APIEvent::Type::ParameterOutOfRange, APIEvent::Severity::Error);
				return std::nullopt;
		}
	}

	std::optional<bool> isPerfTestEnabled() const override {
		auto cfg = getStructurePointer<neovired2_settings_t>();
		if(cfg == nullptr)
			return std::nullopt;
		
		return std::make_optional<bool>(cfg->perf_en != 0);
	}

	bool setPerfTestEnable(bool enable) override {
		auto cfg = getMutableStructurePointer<neovired2_settings_t>();
		if(cfg == nullptr)
			return false;

		cfg->perf_en = !!enable;
		return true;
	}

protected:
	ICSNEO_UNALIGNED(const uint64_t*) getTerminationEnables() const override {
		auto cfg = getStructurePointer<neovired2_settings_t>();
		if(cfg == nullptr)
			return nullptr;
		return &cfg->termination_enables;
	}

	const RAD_GPTP_SETTINGS* getGPTPSettings() const override {
		auto cfg = getStructurePointer<neovired2_settings_t>();
		return cfg ? &cfg->gPTP : nullptr;
	}
	RAD_GPTP_SETTINGS* getMutableGPTPSettings() override {
		auto cfg = getMutableStructurePointer<neovired2_settings_t>();
		return cfg ? &cfg->gPTP : nullptr;
	}
};

}

#endif // __cplusplus

#endif