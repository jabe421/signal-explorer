#ifndef __ETHPHYMESSAGE_H__
#define __ETHPHYMESSAGE_H__

#ifdef __cplusplus

#include "icsneo/communication/packet/ethphyregpacket.h"
#include "icsneo/communication/message/message.h"
#include "icsneo/communication/packet.h"
#include <vector>
#include <memory>
#include <optional>

namespace icsneo {

#ifdef _MSC_VER
#pragma warning(push)
#pragma warning(disable : 4201) // nameless struct/union
#endif

struct PhyMessage {
	bool Enabled = false;
	bool WriteEnable = false;
	bool Clause45Enable = false;
	uint8_t BusIndex = 0;
	uint8_t Version = PhyPacketVersion;
	// Unset on locally constructed messages; every decoded response sets the raw wire status.
	// Ignored when sending. A value does not establish firmware error coverage.
	std::optional<uint8_t> Status;
	union {
		Clause22Message Clause22{};
		Clause45Message Clause45;
	};
};

#ifdef _MSC_VER
#pragma warning(pop)
#endif

//Internal message which provides an interface with device ethernet PHY registers,
//with Clause22 and Clause45 message support
class EthPhyMessage : public Message {
public:
	EthPhyMessage() : Message(Message::Type::EthernetPhyRegister) {}
	bool appendPhyMessage(bool writeEnable, bool clause45, uint8_t phyAddrOrPort, uint8_t pageOrDevice, uint16_t regAddr, uint16_t regVal = 0x0000u, bool enabled = true);
	bool appendPhyMessage(std::shared_ptr<PhyMessage> message);
	size_t getMessageCount() const;

	std::vector<std::shared_ptr<PhyMessage>> messages;
};

}

#endif // __cplusplus

#endif