# libicsneo

libicsneo is the [Intrepid Control Systems](https://intrepidcs.com/) device
communication library. Installation and usage documentation can be found within
each of the respective APIs.

## Installation

libicsneo relies on Servd, IntrepidCS's device communication server.

Servd can be installed for all platforms from https://cdn.intrepidcs.net/servd/.

Instructions for installing each API can be found in its respective documentation.

## Documentation

- [C++](https://libicsneo.readthedocs.io/en/latest/icsneocpp/)
- [Python](https://libicsneo.readthedocs.io/en/latest/icsneopy/)
- [C](https://libicsneo.readthedocs.io/en/latest/icsneoc/) (deprecated, use C2)
- [C2](https://libicsneo.readthedocs.io/en/latest/icsneoc2/)

## Hardware Support

- EtherBADGE
- neoVI Connect
- neoVI FIRE
- neoVI FIRE 2
- neoVI FIRE 3
- neoVI ION
- neoVI PLASMA
- neoVI RED 2
- RAD-A2B
- RAD-Argos
- RAD-Comet 2
- RAD-Comet 3
- RAD-Epsilon
- RAD-EpsilonXL
- RAD-Galaxy
- RAD-Galaxy 2
- RAD-Gigastar
- RAD-Gigastar 2
- RAD-Moon 2
- RAD-Moon 3
- RAD-Moon T1S
- RAD-Pluto
- RAD-Star 2
- RAD-SuperMoon
- RAD-wBMS
- ValueCAN 3
- ValueCAN 4

## License

libicsneo is licensed as BSD-3 with an extra clause, see [LICENSE](LICENSE)
for more details.
